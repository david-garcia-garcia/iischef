<?php

$arguments = [];
parse_str($_SERVER['QUERY_STRING'], $arguments);

$pwd = isset($arguments['pwd']) ? $arguments['pwd'] : NULL;
$key = isset($arguments['key']) ? $arguments['key'] : NULL;

// Nada... una micro protecci�n.
if ($pwd !== "123") {
  http_response_code(401);
  return;
}

$parts = explode('.', $key);
$filename = reset($parts);

$dir = ".well-known/acme-challenge";
@mkdir($dir, 0777, TRUE);

$p = realpath("$dir");

file_put_contents("$dir/$filename", $key);

// Este web.config es para que el response salga como debe....
$webconfig = <<<EOF
<?xml version="1.0" encoding="UTF-8"?>
 <configuration>
     <system.webServer>
	     <httpProtocol>
         <customHeaders>
             <add name="Cache-Control" value="no-cache" />
            </customHeaders>
         </httpProtocol>
         <staticContent>
             <mimeMap fileExtension="." mimeType="text/plain" />
			 <clientCache cacheControlMode="DisableCache" />
         </staticContent>
		 <caching>
            <profiles>
              <add extension="." kernelCachePolicy="DontCache" policy="DontCache"/>
            </profiles>
         </caching>
		 <rewrite>
           <rules>
             <clear />
		   </rules>
         </rewrite>
     </system.webServer>
 </configuration>
EOF;

file_put_contents("$dir/web.config", $webconfig);