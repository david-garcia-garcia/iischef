<?php

echo 'Hello world!';