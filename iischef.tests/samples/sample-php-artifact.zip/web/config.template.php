<?php

$settings = [
	'{@mycustomsetting1|filter:allforward@}',
	'{@mycustomsetting2|filter:trimpath@}',
	'{@mycustomsetting3|filter:allforward,trimpath@}',
	'{@deployment.artifact.id|filter:jsonescape@}',
	'{@deployment.artifact.version|filter:jsonescape@}'
];

foreach($settings as $s) {
	echo($s);
	echo(PHP_EOL);
	echo('<br/>');
}

echo('<hr/>');

$jsonSettings = json_decode("{@!$|filter:jsonescape@}");
echo json_encode($jsonSettings);
echo(PHP_EOL);
echo('<hr/>');

$jsonSettings2 = json_decode("{@!$.cdn|filter:jsonescape@}");
echo json_encode($jsonSettings2);
echo(PHP_EOL);
echo('<hr/>');